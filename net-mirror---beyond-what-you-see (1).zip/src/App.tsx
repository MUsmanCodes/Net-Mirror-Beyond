/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect, useCallback, useRef } from 'react';
import { DESTINATION_URL } from './config/navigation';
import { validateDestinationUrl, openDestinationInNewTab } from './utils/urlValidator';
import { BackgroundCinematic } from './components/BackgroundCinematic';
import { ParticleVortex } from './components/ParticleVortex';
import { LogoSection } from './components/LogoSection';
import { PortalButton } from './components/PortalButton';
import { FooterAttribution } from './components/FooterAttribution';
import { AudioController } from './components/AudioController';
import { UrlNoticeModal } from './components/UrlNoticeModal';

export default function App() {
  // Cinematic Intro Phases: 0 (black), 1 (red ambience), 2 (character), 3 (logo), 4 (fully interactive)
  const [introPhase, setIntroPhase] = useState<number>(0);
  const [parallaxOffset, setParallaxOffset] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [shockwaveActive, setShockwaveActive] = useState(false);
  const [shockwaveOrigin, setShockwaveOrigin] = useState<{ x: number; y: number }>({ x: 0, y: 0 });

  // Modal notification state
  const [modalState, setModalState] = useState<{
    isOpen: boolean;
    type: 'empty' | 'invalid' | 'blocked' | 'success';
    error?: string;
    targetUrl?: string;
  }>({
    isOpen: false,
    type: 'empty',
  });

  const mainContainerRef = useRef<HTMLDivElement | null>(null);

  // Cinematic opening sequence timing
  useEffect(() => {
    // Check prefers-reduced-motion
    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    if (prefersReducedMotion) {
      setIntroPhase(4);
      return;
    }

    const t1 = setTimeout(() => setIntroPhase(1), 150);
    const t2 = setTimeout(() => setIntroPhase(2), 650);
    const t3 = setTimeout(() => setIntroPhase(3), 1200);
    const t4 = setTimeout(() => setIntroPhase(4), 1800);

    return () => {
      clearTimeout(t1);
      clearTimeout(t2);
      clearTimeout(t3);
      clearTimeout(t4);
    };
  }, []);

  // Mouse & Touch Parallax tracking
  const handlePointerMove = useCallback((e: React.PointerEvent<HTMLDivElement>) => {
    const width = window.innerWidth;
    const height = window.innerHeight;
    const normX = (e.clientX - width / 2) / (width / 2);
    const normY = (e.clientY - height / 2) / (height / 2);
    setParallaxOffset({
      x: Math.max(-1, Math.min(1, normX)),
      y: Math.max(-1, Math.min(1, normY)),
    });
  }, []);

  // Handle Main "ENTER NET MIRROR" action
  const handleEnterNetMirror = useCallback((e: React.MouseEvent | React.KeyboardEvent) => {
    // Calculate shockwave origin
    let originX = window.innerWidth / 2;
    let originY = window.innerHeight * 0.72;

    if ('clientX' in e && e.clientX && e.clientY) {
      originX = e.clientX;
      originY = e.clientY;
    }

    setShockwaveOrigin({ x: originX, y: originY });
    setShockwaveActive(true);
    setTimeout(() => setShockwaveActive(false), 900);

    // Validate the destination URL configuration
    const validation = validateDestinationUrl(DESTINATION_URL);

    if (validation.isEmpty) {
      setModalState({
        isOpen: true,
        type: 'empty',
        error: validation.error,
      });
      return;
    }

    if (!validation.isValid) {
      setModalState({
        isOpen: true,
        type: 'invalid',
        error: validation.error,
      });
      return;
    }

    // URL is valid: attempt opening in a new browser tab
    const navResult = openDestinationInNewTab(validation.sanitizedUrl!);

    if (!navResult.opened) {
      // Browser popup blocker prevented automatic tab opening
      setModalState({
        isOpen: true,
        type: 'blocked',
        targetUrl: validation.sanitizedUrl,
        error: navResult.error,
      });
    }
  }, []);

  const closeModal = () => {
    setModalState((prev) => ({ ...prev, isOpen: false }));
  };

  return (
    <div
      ref={mainContainerRef}
      onPointerMove={handlePointerMove}
      className="relative flex min-h-screen w-full flex-col items-center justify-between overflow-hidden bg-black text-white select-none"
    >
      {/* 1. Cinematic Background with Parallax & Superhero Monster Artwork */}
      <BackgroundCinematic parallaxOffset={parallaxOffset} introPhase={introPhase} />

      {/* 2. 3D Particle & Ember Vortex Simulation */}
      <ParticleVortex shockwaveActive={shockwaveActive} shockwaveOrigin={shockwaveOrigin} />

      {/* 3. Audio Atmosphere Controller (Mute / Unmute) */}
      <AudioController />

      {/* 4. Top Decorative Portal Aura */}
      <header className="relative z-10 w-full pt-6 text-center">
        {/* Intentionally minimal top header to let the cinematic character & logo dominate */}
      </header>

      {/* 5. Center Hero Core: NET MIRROR Dripping Logo, Headlines & Interactive Button */}
      <main className="relative z-20 flex w-full max-w-5xl flex-1 flex-col items-center justify-center px-3 pt-3 pb-12 sm:px-6 sm:pt-4 sm:pb-14 md:py-8">
        <LogoSection introPhase={introPhase} parallaxOffset={parallaxOffset} />
        <PortalButton onEnter={handleEnterNetMirror} introPhase={introPhase} />
      </main>

      {/* 6. Footer Attribution: 'developed by Shan Awan' */}
      <FooterAttribution introPhase={introPhase} />

      {/* 7. Destination Configuration & Navigation Feedback Modal */}
      <UrlNoticeModal
        isOpen={modalState.isOpen}
        onClose={closeModal}
        statusType={modalState.type}
        errorMessage={modalState.error}
        targetUrl={modalState.targetUrl}
      />
    </div>
  );
}
