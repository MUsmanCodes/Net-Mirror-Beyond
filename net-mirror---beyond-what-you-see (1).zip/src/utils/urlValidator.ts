/**
 * Utility functions for validating and safely navigating to the destination URL.
 */

export interface UrlValidationResult {
  isValid: boolean;
  isEmpty: boolean;
  error?: string;
  sanitizedUrl?: string;
}

/**
 * Validates a target URL against security and protocol constraints.
 * Allows only HTTP and HTTPS protocols. Strictly prohibits javascript:, data:, and relative URLs.
 */
export function validateDestinationUrl(rawUrl: string | undefined | null): UrlValidationResult {
  if (!rawUrl || typeof rawUrl !== 'string' || rawUrl.trim() === '') {
    return {
      isValid: false,
      isEmpty: true,
      error: 'Destination URL is not configured yet.',
    };
  }

  const trimmed = rawUrl.trim();

  try {
    const parsed = new URL(trimmed);
    const protocol = parsed.protocol.toLowerCase();

    if (protocol !== 'https:' && protocol !== 'http:') {
      return {
        isValid: false,
        isEmpty: false,
        error: `Insecure or unsupported protocol: "${protocol}". Only http: and https: are permitted.`,
      };
    }

    return {
      isValid: true,
      isEmpty: false,
      sanitizedUrl: parsed.toString(),
    };
  } catch {
    return {
      isValid: false,
      isEmpty: false,
      error: `Invalid URL format: "${trimmed}". Please include https:// or http://.`,
    };
  }
}

/**
 * Attempts to safely open the validated destination URL in a new tab.
 * Returns true if the window opened, false if blocked by browser popup protection.
 */
export function openDestinationInNewTab(url: string): { opened: boolean; error?: string } {
  try {
    const newWindow = window.open(url, '_blank', 'noopener,noreferrer');
    
    // In many browsers, if popup was blocked, window.open returns null or undefined
    if (!newWindow || newWindow.closed || typeof newWindow.closed === 'undefined') {
      return { opened: false, error: 'Popup window was blocked by the browser.' };
    }
    
    return { opened: true };
  } catch (err) {
    return {
      opened: false,
      error: err instanceof Error ? err.message : 'Unknown navigation error occurred.',
    };
  }
}
