/**
 * Web Audio API procedural sound synthesizer for NET MIRROR.
 * Generates cinematic portal whooshes and water drip sound effects
 * entirely in code without any external audio file dependencies.
 */

class SoundSynthesizer {
  private ctx: AudioContext | null = null;
  private isMuted: boolean = true; // start muted for user comfort

  private getContext(): AudioContext | null {
    if (typeof window === 'undefined') return null;
    if (!this.ctx) {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
    return this.ctx;
  }

  public setMuted(muted: boolean): void {
    this.isMuted = muted;
    if (!muted) {
      this.getContext();
    }
  }

  public getIsMuted(): boolean {
    return this.isMuted;
  }

  public toggleMute(): boolean {
    this.setMuted(!this.isMuted);
    return this.isMuted;
  }

  /**
   * Cinematic portal activation sound:
   * Sub-bass dive + resonant lowpass filter sweep + metallic harmonic shimmer
   */
  public playPortalActivation(): void {
    if (this.isMuted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;

      // 1. Sub-bass boom
      const subOsc = ctx.createOscillator();
      const subGain = ctx.createGain();
      subOsc.type = 'sine';
      subOsc.frequency.setValueAtTime(140, now);
      subOsc.frequency.exponentialRampToValueAtTime(32, now + 1.2);
      
      subGain.gain.setValueAtTime(0.4, now);
      subGain.gain.exponentialRampToValueAtTime(0.001, now + 1.4);

      subOsc.connect(subGain);
      subGain.connect(ctx.destination);
      subOsc.start(now);
      subOsc.stop(now + 1.4);

      // 2. Whoosh noise / harmonic sweep
      const sweepOsc = ctx.createOscillator();
      const sweepFilter = ctx.createBiquadFilter();
      const sweepGain = ctx.createGain();

      sweepOsc.type = 'sawtooth';
      sweepOsc.frequency.setValueAtTime(80, now);
      sweepOsc.frequency.exponentialRampToValueAtTime(350, now + 0.3);
      sweepOsc.frequency.exponentialRampToValueAtTime(45, now + 1.0);

      sweepFilter.type = 'lowpass';
      sweepFilter.frequency.setValueAtTime(200, now);
      sweepFilter.frequency.exponentialRampToValueAtTime(2200, now + 0.25);
      sweepFilter.frequency.exponentialRampToValueAtTime(120, now + 1.0);
      sweepFilter.Q.setValueAtTime(6, now);

      sweepGain.gain.setValueAtTime(0.01, now);
      sweepGain.gain.linearRampToValueAtTime(0.25, now + 0.2);
      sweepGain.gain.exponentialRampToValueAtTime(0.001, now + 1.1);

      sweepOsc.connect(sweepFilter);
      sweepFilter.connect(sweepGain);
      sweepGain.connect(ctx.destination);

      sweepOsc.start(now);
      sweepOsc.stop(now + 1.1);
    } catch {
      // Audio playback fails gracefully if blocked
    }
  }

  /**
   * Water droplet splash chime
   */
  public playWaterDrip(): void {
    if (this.isMuted) return;
    const ctx = this.getContext();
    if (!ctx) return;

    try {
      const now = ctx.currentTime;
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();

      osc.type = 'sine';
      // Typical water drip pitch drops slightly then decays fast
      const baseFreq = 950 + Math.random() * 250;
      osc.frequency.setValueAtTime(baseFreq, now);
      osc.frequency.exponentialRampToValueAtTime(baseFreq * 0.7, now + 0.12);

      gain.gain.setValueAtTime(0.12, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.15);

      osc.connect(gain);
      gain.connect(ctx.destination);

      osc.start(now);
      osc.stop(now + 0.15);
    } catch {
      // Graceful fallback
    }
  }
}

export const soundSynth = new SoundSynthesizer();
