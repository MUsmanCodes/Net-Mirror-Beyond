import React from 'react';
import { render, screen, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import '@testing-library/jest-dom/vitest';
import App from '../App';

describe('Viewport and Accessibility Verification', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
  });

  const testViewports = [
    { name: 'Desktop', width: 1920, height: 1080 },
    { name: 'Laptop', width: 1366, height: 768 },
    { name: 'Tablet', width: 768, height: 1024 },
    { name: 'Mobile', width: 390, height: 844 },
    { name: 'Small mobile', width: 320, height: 568 },
  ];

  testViewports.forEach(({ name, width, height }) => {
    it(`renders cleanly on ${name} (${width}x${height}) without throwing`, () => {
      // Mock window dimensions
      window.innerWidth = width;
      window.innerHeight = height;

      const { container } = render(<App />);

      act(() => {
        vi.advanceTimersByTime(2500);
      });

      // Assert key elements exist and are accessible
      expect(screen.getByRole('heading', { level: 1, name: /NET/i })).toBeInTheDocument();
      expect(screen.getByRole('heading', { level: 2, name: /MIRROR/i })).toBeInTheDocument();
      expect(screen.getByRole('button', { name: /Enter NET MIRROR portal/i })).toBeInTheDocument();
      expect(screen.getByText(/Destination:/i)).toBeInTheDocument();
      expect(screen.getByText(/net77\.cc/i)).toBeInTheDocument();
      expect(screen.getByText(/developed by/i)).toBeInTheDocument();

      // Ensure root container has overflow-x hidden
      const mainDiv = container.firstChild as HTMLElement;
      expect(mainDiv).toHaveClass('overflow-hidden');
    });
  });

  it('immediately jumps to final phase when prefers-reduced-motion is enabled', () => {
    // Mock reduced motion
    window.matchMedia = vi.fn().mockImplementation((query) => ({
      matches: query === '(prefers-reduced-motion: reduce)',
      media: query,
      onchange: null,
      addListener: vi.fn(),
      removeListener: vi.fn(),
      addEventListener: vi.fn(),
      removeEventListener: vi.fn(),
      dispatchEvent: vi.fn(),
    }));

    render(<App />);

    // In reduced motion, elements should be available immediately without timer advance
    expect(screen.getByRole('button', { name: /Enter NET MIRROR portal/i })).toBeInTheDocument();
    expect(screen.getByText(/BEYOND WHAT YOU SEE/i)).toBeInTheDocument();
  });

  it('provides accessible names and roles for audio controls', () => {
    render(<App />);

    const audioBtn = screen.getByRole('button', { name: /cinematic sound effects/i });
    expect(audioBtn).toBeInTheDocument();
    expect(audioBtn).toHaveAttribute('type', 'button');
  });
});
