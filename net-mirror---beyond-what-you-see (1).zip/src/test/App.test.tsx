import React from 'react';
import { render, screen, fireEvent, act } from '@testing-library/react';
import { describe, it, expect, vi, beforeEach, afterEach } from 'vitest';
import '@testing-library/jest-dom/vitest';
import App from '../App';
import { DESTINATION_URL } from '../config/navigation';

describe('NET MIRROR Landing Page Integration', () => {
  beforeEach(() => {
    vi.useFakeTimers();
  });

  afterEach(() => {
    vi.useRealTimers();
    vi.restoreAllMocks();
  });

  it('renders landing page with NET MIRROR logo, headlines, button, and visible destination link', () => {
    render(<App />);

    // Fast-forward opening animation sequence
    act(() => {
      vi.advanceTimersByTime(2500);
    });

    // Check logo parts
    expect(screen.getByRole('heading', { level: 1, name: /NET/i })).toBeInTheDocument();
    expect(screen.getByRole('heading', { level: 2, name: /MIRROR/i })).toBeInTheDocument();

    // Check English headlines
    expect(screen.getByText(/BEYOND WHAT YOU SEE/i)).toBeInTheDocument();
    expect(screen.getByText(/A NEW WORLD AWAITS/i)).toBeInTheDocument();

    // Check main button
    const enterButton = screen.getByRole('button', { name: /Enter NET MIRROR portal/i });
    expect(enterButton).toBeInTheDocument();
    expect(enterButton).toHaveTextContent(/ENTER NET MIRROR/i);

    // Check that the destination link is visible directly on page
    expect(screen.getByText(/Destination:/i)).toBeInTheDocument();
    const linkElement = screen.getByTitle(DESTINATION_URL);
    expect(linkElement).toBeInTheDocument();
    expect(linkElement).toHaveAttribute('href', 'https://net77.cc/home?utm_source=home_page');

    // Check developer attribution footer
    expect(screen.getByText(/developed by/i)).toBeInTheDocument();
    expect(screen.getByText(/Shan Awan/i)).toBeInTheDocument();
  });

  it('navigates to configured destination URL in new tab when clicking ENTER NET MIRROR', () => {
    const openMock = vi.fn().mockReturnValue({ closed: false });
    window.open = openMock;

    render(<App />);

    act(() => {
      vi.advanceTimersByTime(2500);
    });

    const enterButton = screen.getByRole('button', { name: /Enter NET MIRROR portal/i });
    fireEvent.click(enterButton);

    expect(openMock).toHaveBeenCalledWith(
      'https://net77.cc/home?utm_source=home_page',
      '_blank',
      'noopener,noreferrer'
    );
  });

  it('supports keyboard navigation via Enter and Space to open destination URL', () => {
    const openMock = vi.fn().mockReturnValue({ closed: false });
    window.open = openMock;

    render(<App />);

    act(() => {
      vi.advanceTimersByTime(2500);
    });

    const enterButton = screen.getByRole('button', { name: /Enter NET MIRROR portal/i });

    // Press Enter
    fireEvent.keyDown(enterButton, { key: 'Enter', code: 'Enter' });
    expect(openMock).toHaveBeenCalledWith(
      'https://net77.cc/home?utm_source=home_page',
      '_blank',
      'noopener,noreferrer'
    );

    openMock.mockClear();

    // Press Space
    fireEvent.keyDown(enterButton, { key: ' ', code: 'Space' });
    expect(openMock).toHaveBeenCalledWith(
      'https://net77.cc/home?utm_source=home_page',
      '_blank',
      'noopener,noreferrer'
    );
  });

  it('handles blocked popup gracefully by showing popup blocked dialog with fallback link', () => {
    // Simulate browser popup blocker returning null
    window.open = vi.fn().mockReturnValue(null);

    render(<App />);

    act(() => {
      vi.advanceTimersByTime(2500);
    });

    const enterButton = screen.getByRole('button', { name: /Enter NET MIRROR portal/i });
    fireEvent.click(enterButton);

    // Fallback modal should display
    expect(screen.getByText(/POPUP WINDOW BLOCKED/i)).toBeInTheDocument();
    expect(screen.getByText(/Open https:\/\/net77\.cc\/home\?utm_source=home_page/i)).toBeInTheDocument();
  });
});
