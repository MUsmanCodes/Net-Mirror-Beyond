import { describe, it, expect, vi, beforeEach } from 'vitest';
import { validateDestinationUrl, openDestinationInNewTab } from '../utils/urlValidator';

describe('validateDestinationUrl', () => {
  it('identifies empty or null URLs', () => {
    expect(validateDestinationUrl('')).toEqual({
      isValid: false,
      isEmpty: true,
      error: 'Destination URL is not configured yet.',
    });

    expect(validateDestinationUrl('   ')).toEqual({
      isValid: false,
      isEmpty: true,
      error: 'Destination URL is not configured yet.',
    });

    expect(validateDestinationUrl(null)).toEqual({
      isValid: false,
      isEmpty: true,
      error: 'Destination URL is not configured yet.',
    });
  });

  it('validates secure HTTPS URLs properly', () => {
    const result = validateDestinationUrl('https://destination-website.com');
    expect(result.isValid).toBe(true);
    expect(result.isEmpty).toBe(false);
    expect(result.sanitizedUrl).toBe('https://destination-website.com/');
  });

  it('validates HTTP URLs properly', () => {
    const result = validateDestinationUrl('http://example.org/path?key=val');
    expect(result.isValid).toBe(true);
    expect(result.isEmpty).toBe(false);
    expect(result.sanitizedUrl).toBe('http://example.org/path?key=val');
  });

  it('strictly rejects malicious javascript: schemes', () => {
    const result = validateDestinationUrl('javascript:alert(1)');
    expect(result.isValid).toBe(false);
    expect(result.isEmpty).toBe(false);
    expect(result.error).toContain('Insecure or unsupported protocol');
  });

  it('strictly rejects data: and file: schemes', () => {
    const dataRes = validateDestinationUrl('data:text/html,<h1>test</h1>');
    expect(dataRes.isValid).toBe(false);

    const fileRes = validateDestinationUrl('file:///etc/passwd');
    expect(fileRes.isValid).toBe(false);
  });

  it('handles malformed string inputs without crashing', () => {
    const result = validateDestinationUrl('not-a-valid-url');
    expect(result.isValid).toBe(false);
    expect(result.isEmpty).toBe(false);
    expect(result.error).toContain('Invalid URL format');
  });
});

describe('openDestinationInNewTab', () => {
  beforeEach(() => {
    vi.restoreAllMocks();
  });

  it('attempts to open the destination with noopener and noreferrer', () => {
    const openMock = vi.fn().mockReturnValue({ closed: false });
    window.open = openMock;

    const result = openDestinationInNewTab('https://example.com');
    expect(openMock).toHaveBeenCalledWith('https://example.com', '_blank', 'noopener,noreferrer');
    expect(result.opened).toBe(true);
  });

  it('reports blocked popups when window.open returns null', () => {
    window.open = vi.fn().mockReturnValue(null);

    const result = openDestinationInNewTab('https://example.com');
    expect(result.opened).toBe(false);
    expect(result.error).toContain('Popup window was blocked');
  });
});
