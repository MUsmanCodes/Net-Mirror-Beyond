import React, { useEffect, useState } from 'react';
import { soundSynth } from '../utils/audio';

interface DropletConfig {
  id: number;
  leftPercent: number; // horizontal position across the logo (0 - 100%)
  startYPercent: number; // starting point on the letter
  fallDistancePx: number; // distance before detach
  color: 'red' | 'chrome';
  delaySec: number;
  durationSec: number;
  sizePx: number;
}

const DEFAULT_DROPLETS: DropletConfig[] = [
  // Red "NET" letters droplets
  { id: 1, leftPercent: 24, startYPercent: 20, fallDistancePx: 58, color: 'red', delaySec: 0.2, durationSec: 3.8, sizePx: 5 },
  { id: 2, leftPercent: 32, startYPercent: 28, fallDistancePx: 72, color: 'red', delaySec: 1.8, durationSec: 4.2, sizePx: 6 },
  { id: 3, leftPercent: 44, startYPercent: 16, fallDistancePx: 65, color: 'red', delaySec: 0.9, durationSec: 3.5, sizePx: 4.5 },
  { id: 4, leftPercent: 53, startYPercent: 25, fallDistancePx: 80, color: 'red', delaySec: 2.4, durationSec: 4.0, sizePx: 7 },
  { id: 5, leftPercent: 62, startYPercent: 18, fallDistancePx: 70, color: 'red', delaySec: 1.2, durationSec: 3.9, sizePx: 5 },
  
  // Metallic "MIRROR" letters droplets
  { id: 6, leftPercent: 16, startYPercent: 54, fallDistancePx: 65, color: 'chrome', delaySec: 0.5, durationSec: 3.6, sizePx: 6 },
  { id: 7, leftPercent: 26, startYPercent: 60, fallDistancePx: 75, color: 'chrome', delaySec: 2.1, durationSec: 4.4, sizePx: 5.5 },
  { id: 8, leftPercent: 36, startYPercent: 56, fallDistancePx: 68, color: 'chrome', delaySec: 1.4, durationSec: 3.7, sizePx: 5 },
  { id: 9, leftPercent: 48, startYPercent: 52, fallDistancePx: 78, color: 'chrome', delaySec: 2.9, durationSec: 4.1, sizePx: 6.5 },
  { id: 10, leftPercent: 58, startYPercent: 58, fallDistancePx: 70, color: 'chrome', delaySec: 0.8, durationSec: 3.4, sizePx: 4.5 },
  { id: 11, leftPercent: 70, startYPercent: 55, fallDistancePx: 82, color: 'chrome', delaySec: 2.6, durationSec: 4.3, sizePx: 6 },
  { id: 12, leftPercent: 82, startYPercent: 57, fallDistancePx: 64, color: 'chrome', delaySec: 1.6, durationSec: 3.8, sizePx: 5.5 },
];

export const WaterDropletsLayer: React.FC = () => {
  const [interactiveRipples, setInteractiveRipples] = useState<{ id: number; x: number; y: number }[]>([]);

  useEffect(() => {
    // Periodic random drip sound (only plays if user unmuted sound)
    const interval = setInterval(() => {
      if (Math.random() > 0.45) {
        soundSynth.playWaterDrip();
      }
    }, 4500);

    return () => clearInterval(interval);
  }, []);

  const triggerWaterRipple = (e: React.MouseEvent) => {
    const rect = e.currentTarget.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    const id = Date.now();

    setInteractiveRipples((prev) => [...prev.slice(-5), { id, x, y }]);
    soundSynth.playWaterDrip();

    setTimeout(() => {
      setInteractiveRipples((prev) => prev.filter((r) => r.id !== id));
    }, 1200);
  };

  return (
    <div
      className="pointer-events-auto absolute inset-0 z-20 overflow-hidden"
      onClick={triggerWaterRipple}
      title="Interactive wet surface (click to ripple)"
    >
      {/* SVG filter for natural liquid refraction */}
      <svg className="hidden">
        <defs>
          <filter id="water-filter">
            <feGaussianBlur in="SourceGraphic" stdDeviation="1.5" result="blur" />
            <feColorMatrix
              in="blur"
              mode="matrix"
              values="1 0 0 0 0  0 1 0 0 0  0 0 1 0 0  0 0 0 18 -7"
              result="liquid"
            />
            <feBlend in="SourceGraphic" in2="liquid" />
          </filter>
        </defs>
      </svg>

      {/* Droplet paths and animated tears */}
      {DEFAULT_DROPLETS.map((drop) => (
        <div
          key={drop.id}
          className="pointer-events-none absolute"
          style={{
            left: `${drop.leftPercent}%`,
            top: `${drop.startYPercent}%`,
          }}
        >
          {/* Subtle wet glistening trail left behind the droplet */}
          <div
            className="absolute -top-1 w-[2px] -translate-x-1/2 opacity-35"
            style={{
              height: `${drop.fallDistancePx * 0.9}px`,
              background:
                drop.color === 'red'
                  ? 'linear-gradient(180deg, rgba(255, 0, 51, 0.45) 0%, rgba(255, 0, 51, 0.1) 80%, transparent 100%)'
                  : 'linear-gradient(180deg, rgba(255, 255, 255, 0.6) 0%, rgba(255, 255, 255, 0.15) 80%, transparent 100%)',
              boxShadow: drop.color === 'red' ? '0 0 6px rgba(255, 0, 51, 0.5)' : '0 0 4px rgba(255, 255, 255, 0.4)',
            }}
          />

          {/* Sliding water droplet */}
          <div
            className="animate-droplet absolute -translate-x-1/2 rounded-full"
            style={{
              width: `${drop.sizePx}px`,
              height: `${drop.sizePx * 1.5}px`,
              animationDuration: `${drop.durationSec}s`,
              animationDelay: `${drop.delaySec}s`,
              background:
                drop.color === 'red'
                  ? 'radial-gradient(circle at 35% 30%, #ff8095 0%, #ff0033 60%, #8b0000 100%)'
                  : 'radial-gradient(circle at 35% 30%, #ffffff 0%, #e2e8f0 40%, rgba(148, 163, 184, 0.9) 100%)',
              boxShadow:
                drop.color === 'red'
                  ? '0 2px 8px rgba(255, 0, 51, 0.9), inset 1px 1px 2px rgba(255, 255, 255, 0.8)'
                  : '0 2px 8px rgba(255, 255, 255, 0.7), inset 1px 1px 2px rgba(255, 255, 255, 1)',
            }}
          >
            {/* Specular highlight glint */}
            <span className="absolute top-[15%] left-[25%] h-[30%] w-[35%] rounded-full bg-white opacity-90" />
          </div>
        </div>
      ))}

      {/* Interactive water ripples on click */}
      {interactiveRipples.map((ripple) => (
        <span
          key={ripple.id}
          className="pointer-events-none absolute -translate-x-1/2 -translate-y-1/2 rounded-full border border-red-500/80"
          style={{
            left: ripple.x,
            top: ripple.y,
            animation: 'portalShockwave 1.1s cubic-bezier(0.1, 0.8, 0.3, 1) forwards',
          }}
        />
      ))}
    </div>
  );
};
