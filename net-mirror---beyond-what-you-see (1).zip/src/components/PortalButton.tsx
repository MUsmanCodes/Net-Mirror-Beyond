import React, { useRef, useState } from 'react';
import { ArrowRight, ExternalLink, Link2, Check } from 'lucide-react';
import { soundSynth } from '../utils/audio';
import { DESTINATION_URL } from '../config/navigation';

interface PortalButtonProps {
  onEnter: (e: React.MouseEvent<HTMLButtonElement> | React.KeyboardEvent<HTMLButtonElement>) => void;
  introPhase: number;
}

export const PortalButton: React.FC<PortalButtonProps> = ({ onEnter, introPhase }) => {
  const buttonRef = useRef<HTMLButtonElement | null>(null);
  const [tilt, setTilt] = useState<{ x: number; y: number }>({ x: 0, y: 0 });
  const [isPressed, setIsPressed] = useState(false);
  const [isHovered, setIsHovered] = useState(false);
  const [copied, setCopied] = useState(false);

  // Dynamic 3D tilt calculation on pointer movement over button
  const handlePointerMove = (e: React.PointerEvent<HTMLButtonElement>) => {
    if (!buttonRef.current) return;
    const rect = buttonRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;
    const deltaX = (e.clientX - centerX) / (rect.width / 2);
    const deltaY = (e.clientY - centerY) / (rect.height / 2);

    // Limit tilt to max 8 degrees
    setTilt({
      x: -deltaY * 8,
      y: deltaX * 8,
    });
  };

  const handlePointerLeave = () => {
    setTilt({ x: 0, y: 0 });
    setIsHovered(false);
  };

  const handlePointerEnter = () => {
    setIsHovered(true);
  };

  const handleClick = (e: React.MouseEvent<HTMLButtonElement>) => {
    soundSynth.playPortalActivation();
    setIsPressed(true);
    setTimeout(() => setIsPressed(false), 300);
    onEnter(e);
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLButtonElement>) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      soundSynth.playPortalActivation();
      setIsPressed(true);
      setTimeout(() => setIsPressed(false), 300);
      onEnter(e);
    }
  };

  const handleCopyLink = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (navigator.clipboard && DESTINATION_URL) {
      navigator.clipboard.writeText(DESTINATION_URL).then(() => {
        setCopied(true);
        setTimeout(() => setCopied(false), 2000);
      }).catch(() => {});
    }
  };

  return (
    <div
      className="relative z-20 mt-4 flex flex-col items-center justify-center transition-all duration-700 sm:mt-6 md:mt-8 w-full max-w-xl px-3"
      style={{
        opacity: introPhase >= 4 ? 1 : 0,
        transform: introPhase >= 4 ? 'translateY(0)' : 'translateY(20px)',
      }}
    >
      {/* Outer ambient glow ring under button */}
      <div
        className="pointer-events-none absolute h-16 w-64 rounded-full blur-xl transition-all duration-300 sm:w-80"
        style={{
          background: isHovered
            ? 'radial-gradient(circle, rgba(255, 0, 51, 0.9) 0%, rgba(139, 0, 0, 0.4) 60%, transparent 80%)'
            : 'radial-gradient(circle, rgba(255, 0, 51, 0.6) 0%, rgba(139, 0, 0, 0.2) 60%, transparent 80%)',
          transform: isHovered ? 'scale(1.2)' : 'scale(1)',
        }}
      />

      {/* Main Interactive Button with 3D perspective */}
      <div
        style={{
          perspective: 600,
        }}
      >
        <button
          ref={buttonRef}
          type="button"
          onClick={handleClick}
          onKeyDown={handleKeyDown}
          onPointerMove={handlePointerMove}
          onPointerEnter={handlePointerEnter}
          onPointerLeave={handlePointerLeave}
          aria-label="Enter NET MIRROR portal"
          className="group relative flex min-h-[48px] items-center justify-center gap-3 overflow-hidden rounded-full px-7 py-3 sm:px-10 sm:py-4 transition-all duration-200 outline-none focus-visible:ring-4 focus-visible:ring-[#ff0033] focus-visible:ring-offset-2 focus-visible:ring-offset-black"
          style={{
            transform: `rotateX(${tilt.x}deg) rotateY(${tilt.y}deg) scale(${
              isPressed ? 0.94 : isHovered ? 1.05 : 1
            })`,
            background: 'linear-gradient(180deg, #b30024 0%, #730014 45%, #40000a 100%)',
            border: '1.5px solid rgba(255, 0, 51, 0.9)',
            boxShadow: isHovered
              ? '0 0 35px rgba(255, 0, 51, 0.95), 0 0 70px rgba(255, 0, 51, 0.5), inset 0 0 20px rgba(255, 0, 51, 0.7)'
              : '0 0 25px rgba(255, 0, 51, 0.7), 0 0 45px rgba(255, 0, 51, 0.35), inset 0 0 12px rgba(255, 0, 51, 0.5)',
            transformStyle: 'preserve-3d',
            cursor: 'pointer',
          }}
        >
          {/* Top Half Glass Reflection Highlight */}
          <div
            className="pointer-events-none absolute inset-x-0 top-0 h-1/2 rounded-t-full bg-gradient-to-b from-white/35 to-transparent opacity-80"
          />

          {/* Animated Light Sweep Line */}
          <div className="pointer-events-none absolute inset-0 overflow-hidden">
            <div className="animate-sheen h-full w-1/4 bg-gradient-to-r from-transparent via-white/70 to-transparent blur-xs" />
          </div>

          {/* Button Text */}
          <span className="font-orbitron relative z-10 text-xs font-black tracking-[0.25em] text-white uppercase sm:text-sm md:text-base drop-shadow-[0_2px_4px_rgba(0,0,0,0.9)]">
            ENTER NET MIRROR
          </span>

          {/* Arrow Icon with subtle hover forward nudge */}
          <ArrowRight
            className="relative z-10 h-4 w-4 text-white transition-transform duration-200 group-hover:translate-x-1 sm:h-5 sm:w-5"
            strokeWidth={2.6}
            aria-hidden="true"
          />
        </button>
      </div>

      {/* Secondary Line: A NEW WORLD AWAITS */}
      <div className="mt-3 sm:mt-4 text-center">
        <p
          className="font-montserrat text-[10px] font-semibold tracking-[0.4em] text-white/80 uppercase sm:text-xs"
          style={{
            textShadow: '0 0 8px rgba(255, 0, 51, 0.5), 0 1px 3px rgba(0,0,0,0.9)',
          }}
        >
          A NEW WORLD AWAITS
        </p>
      </div>

      {/* Prominently Visible Gateway Link (Optimized for Mobile, Tablet, Laptop) */}
      {DESTINATION_URL && (
        <div className="mt-3 sm:mt-4 flex w-full flex-col items-center justify-center gap-1.5 text-center">
          <div className="group relative flex max-w-full items-center justify-between gap-2 rounded-xl border border-red-600/50 bg-black/75 px-3 py-1.5 sm:px-4 sm:py-2 backdrop-blur-md shadow-[0_0_20px_rgba(255,0,51,0.25)] transition-all duration-200 hover:border-red-500 hover:shadow-[0_0_30px_rgba(255,0,51,0.4)]">
            <div className="flex items-center gap-1.5 shrink-0 text-red-500">
              <Link2 className="h-3.5 w-3.5 sm:h-4 sm:w-4" aria-hidden="true" />
              <span className="font-mono text-[9px] sm:text-[11px] font-semibold tracking-wider text-neutral-300 uppercase">
                Destination:
              </span>
            </div>

            <a
              href={DESTINATION_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="font-mono text-[10px] sm:text-xs text-red-400 hover:text-white transition-colors truncate max-w-[170px] xs:max-w-[220px] sm:max-w-[320px] md:max-w-[420px] underline decoration-red-600/50 hover:decoration-white focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-[#ff0033] rounded"
              title={DESTINATION_URL}
            >
              {DESTINATION_URL}
            </a>

            <div className="flex items-center gap-1 shrink-0">
              <button
                type="button"
                onClick={handleCopyLink}
                aria-label={copied ? "Link copied" : "Copy destination link"}
                title={copied ? "Copied to clipboard!" : "Copy URL"}
                className="flex h-6 w-6 sm:h-7 sm:w-7 items-center justify-center rounded-md bg-white/10 text-neutral-300 hover:bg-white/20 hover:text-white transition-colors text-[10px]"
              >
                {copied ? (
                  <Check className="h-3 w-3 text-emerald-400" aria-hidden="true" />
                ) : (
                  <span className="font-mono text-[9px]">COPY</span>
                )}
              </button>

              <a
                href={DESTINATION_URL}
                target="_blank"
                rel="noopener noreferrer"
                aria-label="Open destination website in new tab"
                title="Open in new browser tab"
                className="flex h-6 w-6 sm:h-7 sm:w-7 items-center justify-center rounded-md bg-[#ff0033]/80 text-white hover:bg-[#ff0033] transition-colors"
              >
                <ExternalLink className="h-3 w-3 sm:h-3.5 sm:w-3.5" aria-hidden="true" />
              </a>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
