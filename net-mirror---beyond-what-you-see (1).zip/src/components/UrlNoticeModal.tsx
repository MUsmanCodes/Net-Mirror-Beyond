import React, { useState } from 'react';
import { X, ExternalLink, AlertCircle, Info, CheckCircle2 } from 'lucide-react';
import { openDestinationInNewTab, validateDestinationUrl } from '../utils/urlValidator';

interface UrlNoticeModalProps {
  isOpen: boolean;
  onClose: () => void;
  statusType: 'empty' | 'invalid' | 'blocked' | 'success';
  errorMessage?: string;
  targetUrl?: string;
}

export const UrlNoticeModal: React.FC<UrlNoticeModalProps> = ({
  isOpen,
  onClose,
  statusType,
  errorMessage,
  targetUrl,
}) => {
  const [testUrlInput, setTestUrlInput] = useState('');
  const [testError, setTestError] = useState('');

  if (!isOpen) return null;

  const handleTestSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const result = validateDestinationUrl(testUrlInput);
    if (!result.isValid) {
      setTestError(result.error || 'Please enter a valid URL.');
      return;
    }
    setTestError('');
    openDestinationInNewTab(result.sanitizedUrl!);
  };

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4 backdrop-blur-md"
      style={{ backgroundColor: 'rgba(0, 0, 0, 0.85)' }}
      onClick={onClose}
    >
      <div
        className="relative w-full max-w-lg rounded-2xl border border-red-500/40 bg-[#0d0204] p-6 text-white shadow-[0_0_60px_rgba(255,0,51,0.35)] sm:p-8"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Close Button */}
        <button
          type="button"
          onClick={onClose}
          aria-label="Close dialog"
          className="absolute top-4 right-4 rounded-full p-2 text-white/70 transition-colors hover:bg-white/10 hover:text-white focus-visible:ring-2 focus-visible:ring-[#ff0033] outline-none"
        >
          <X className="h-5 w-5" />
        </button>

        {/* Modal Header Icon & Title */}
        <div className="flex items-center gap-3">
          {statusType === 'empty' ? (
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-950/80 border border-red-600/50 text-[#ff0033]">
              <Info className="h-5 w-5" />
            </div>
          ) : statusType === 'invalid' ? (
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-red-950/80 border border-red-600/50 text-[#ff0033]">
              <AlertCircle className="h-5 w-5" />
            </div>
          ) : (
            <div className="flex h-10 w-10 shrink-0 items-center justify-center rounded-full bg-emerald-950/80 border border-emerald-600/50 text-emerald-400">
              <CheckCircle2 className="h-5 w-5" />
            </div>
          )}
          <div>
            <h3 id="modal-title" className="font-orbitron text-lg font-bold tracking-wide text-white">
              {statusType === 'empty'
                ? 'DESTINATION URL PENDING'
                : statusType === 'invalid'
                ? 'INVALID DESTINATION URL'
                : statusType === 'blocked'
                ? 'POPUP WINDOW BLOCKED'
                : 'PORTAL READY'}
            </h3>
            <span className="text-xs text-red-400 font-medium">NET MIRROR Gateway System</span>
          </div>
        </div>

        {/* Modal Body */}
        <div className="mt-5 space-y-4 text-sm text-neutral-300">
          {statusType === 'empty' && (
            <>
              <p>
                The destination website has not yet been configured in the project settings.
              </p>
              <div className="rounded-lg border border-red-900/60 bg-black/60 p-3 font-mono text-xs text-neutral-200">
                <span className="text-red-400">// File:</span> src/config/navigation.ts
                <br />
                <span className="text-purple-400">export const</span>{' '}
                <span className="text-yellow-300">DESTINATION_URL</span> ={' '}
                <span className="text-emerald-300">&quot;https://your-website.com&quot;</span>;
              </div>
              <p className="text-xs text-neutral-400">
                Once configured, clicking &quot;ENTER NET MIRROR&quot; will immediately open your target website in a new tab.
              </p>

              {/* Interactive URL tester for QA & client preview */}
              <div className="mt-4 border-t border-red-950/70 pt-4">
                <p className="text-xs font-semibold uppercase tracking-wider text-neutral-200">
                  Quick Test: Test Navigation Now
                </p>
                <form onSubmit={handleTestSubmit} className="mt-2 flex flex-col gap-2 sm:flex-row">
                  <input
                    type="url"
                    value={testUrlInput}
                    onChange={(e) => setTestUrlInput(e.target.value)}
                    placeholder="https://example.com"
                    className="flex-1 rounded-lg border border-neutral-700 bg-black/80 px-3 py-2 text-xs text-white placeholder-neutral-500 focus:border-[#ff0033] focus:outline-none focus:ring-1 focus:ring-[#ff0033]"
                  />
                  <button
                    type="submit"
                    className="flex items-center justify-center gap-1.5 rounded-lg bg-[#ff0033] px-4 py-2 text-xs font-bold uppercase tracking-wider text-white transition hover:bg-[#d6002b]"
                  >
                    <span>Test Tab</span>
                    <ExternalLink className="h-3.5 w-3.5" />
                  </button>
                </form>
                {testError && <p className="mt-1 text-xs text-red-400">{testError}</p>}
              </div>
            </>
          )}

          {statusType === 'invalid' && (
            <>
              <p>The configured URL failed security validation:</p>
              <div className="rounded-lg border border-red-800/60 bg-red-950/30 p-3 text-xs text-red-300">
                {errorMessage || 'Unknown URL format error.'}
              </div>
              <p className="text-xs text-neutral-400">
                NET MIRROR only permits safe protocols (<code className="text-white">https://</code> and <code className="text-white">http://</code>).
                Protocols like <code className="text-white">javascript:</code> are blocked for safety.
              </p>
            </>
          )}

          {statusType === 'blocked' && (
            <>
              <p>
                Your browser blocked the automatic new tab popup. You can click the direct link below:
              </p>
              {targetUrl && (
                <a
                  href={targetUrl}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 rounded-lg bg-[#ff0033] px-5 py-2.5 text-xs font-bold uppercase tracking-wider text-white hover:bg-[#d6002b]"
                >
                  <span>Open {targetUrl}</span>
                  <ExternalLink className="h-4 w-4" />
                </a>
              )}
            </>
          )}
        </div>

        {/* Modal Actions */}
        <div className="mt-6 flex justify-end">
          <button
            type="button"
            onClick={onClose}
            className="rounded-lg border border-neutral-700 bg-neutral-900 px-5 py-2 text-xs font-semibold uppercase tracking-wider text-neutral-300 transition hover:bg-neutral-800 hover:text-white"
          >
            Acknowledge
          </button>
        </div>
      </div>
    </div>
  );
};
