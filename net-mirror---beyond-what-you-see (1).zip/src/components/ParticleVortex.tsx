import React, { useEffect, useRef } from 'react';

interface Particle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  size: number;
  baseSize: number;
  alpha: number;
  maxAlpha: number;
  life: number;
  maxLife: number;
  color: string;
  glowColor: string;
  depth: number;
}

interface ParticleVortexProps {
  shockwaveActive?: boolean;
  shockwaveOrigin?: { x: number; y: number };
}

export const ParticleVortex: React.FC<ParticleVortexProps> = ({
  shockwaveActive,
  shockwaveOrigin,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const mouseRef = useRef<{ x: number; y: number; active: boolean }>({
    x: 0,
    y: 0,
    active: false,
  });

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let animationFrameId: number;
    let width = (canvas.width = window.innerWidth);
    let height = (canvas.height = window.innerHeight);

    const handleResize = () => {
      if (!canvas) return;
      width = canvas.width = window.innerWidth;
      height = canvas.height = window.innerHeight;
    };

    window.addEventListener('resize', handleResize);

    const prefersReducedMotion = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const particleCount = prefersReducedMotion ? 25 : Math.min(100, Math.floor((width * height) / 14000));

    const particles: Particle[] = [];

    const createParticle = (spawnBottom: boolean = false): Particle => {
      const depth = 0.3 + Math.random() * 0.7; // 0.3 (far) to 1.0 (near)
      const baseSize = (1.5 + Math.random() * 3) * depth;
      const x = Math.random() * width;
      const y = spawnBottom ? height + Math.random() * 50 : Math.random() * height;
      const maxLife = 180 + Math.random() * 240;
      const maxAlpha = (0.3 + Math.random() * 0.6) * depth;

      // Color variation: mostly crimson/ruby red, occasional molten orange-white spark
      const isHotSpark = Math.random() > 0.85;
      const color = isHotSpark ? '#ffffff' : '#ff0033';
      const glowColor = isHotSpark ? 'rgba(255, 120, 80, ' : 'rgba(255, 0, 51, ';

      return {
        x,
        y,
        vx: (Math.random() - 0.5) * 0.4 * depth,
        vy: -(0.4 + Math.random() * 1.0) * depth,
        size: baseSize,
        baseSize,
        alpha: 0,
        maxAlpha,
        life: 0,
        maxLife,
        color,
        glowColor,
        depth,
      };
    };

    for (let i = 0; i < particleCount; i++) {
      particles.push(createParticle(false));
    }

    const handleMouseMove = (e: MouseEvent) => {
      mouseRef.current = {
        x: e.clientX,
        y: e.clientY,
        active: true,
      };
    };

    const handleMouseLeave = () => {
      mouseRef.current.active = false;
    };

    window.addEventListener('mousemove', handleMouseMove);
    window.addEventListener('mouseleave', handleMouseLeave);

    let tick = 0;

    const render = () => {
      tick++;
      ctx.clearRect(0, 0, width, height);

      // Mouse influence
      const mx = mouseRef.current.x;
      const my = mouseRef.current.y;
      const mouseActive = mouseRef.current.active;

      for (let i = 0; i < particles.length; i++) {
        const p = particles[i];
        p.life++;

        // Fade in and out
        if (p.life < 40) {
          p.alpha = (p.life / 40) * p.maxAlpha;
        } else if (p.life > p.maxLife - 60) {
          p.alpha = ((p.maxLife - p.life) / 60) * p.maxAlpha;
        }

        // Gentle floating wave
        const wave = Math.sin(tick * 0.02 + p.depth * 5) * 0.3 * p.depth;
        p.x += p.vx + wave;
        p.y += p.vy;

        // Interactive mouse gentle push
        if (mouseActive) {
          const dx = p.x - mx;
          const dy = p.y - my;
          const dist = Math.sqrt(dx * dx + dy * dy);
          if (dist < 180 && dist > 0) {
            const force = (180 - dist) / 180;
            p.x += (dx / dist) * force * 1.5;
            p.y += (dy / dist) * force * 1.5;
          }
        }

        // Render particle with dual radial glow
        if (p.alpha > 0.01) {
          ctx.save();
          ctx.globalAlpha = p.alpha;

          // Outer halo
          const gradient = ctx.createRadialGradient(p.x, p.y, 0, p.x, p.y, p.size * 3.5);
          gradient.addColorStop(0, p.glowColor + '0.9)');
          gradient.addColorStop(0.5, p.glowColor + '0.3)');
          gradient.addColorStop(1, 'rgba(0, 0, 0, 0)');

          ctx.fillStyle = gradient;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * 3.5, 0, Math.PI * 2);
          ctx.fill();

          // Hot inner core
          ctx.fillStyle = p.color;
          ctx.beginPath();
          ctx.arc(p.x, p.y, p.size * 0.6, 0, Math.PI * 2);
          ctx.fill();

          ctx.restore();
        }

        // Respawn when dead or off screen
        if (p.life >= p.maxLife || p.y < -20 || p.x < -20 || p.x > width + 20) {
          particles[i] = createParticle(true);
        }
      }

      animationFrameId = requestAnimationFrame(render);
    };

    animationFrameId = requestAnimationFrame(render);

    return () => {
      cancelAnimationFrame(animationFrameId);
      window.removeEventListener('resize', handleResize);
      window.removeEventListener('mousemove', handleMouseMove);
      window.removeEventListener('mouseleave', handleMouseLeave);
    };
  }, []);

  // Handle shockwave burst effect
  useEffect(() => {
    if (!shockwaveActive || !canvasRef.current) return;
    const canvas = canvasRef.current;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const origin = shockwaveOrigin || {
      x: window.innerWidth / 2,
      y: window.innerHeight * 0.75,
    };

    let radius = 20;
    let opacity = 0.9;
    let frame: number;

    const expand = () => {
      radius += 18;
      opacity *= 0.94;

      if (opacity > 0.02) {
        ctx.save();
        ctx.beginPath();
        ctx.arc(origin.x, origin.y, radius, 0, Math.PI * 2);
        ctx.strokeStyle = `rgba(255, 0, 51, ${opacity})`;
        ctx.lineWidth = Math.max(1, 8 * opacity);
        ctx.shadowColor = '#ff0033';
        ctx.shadowBlur = 25;
        ctx.stroke();
        ctx.restore();

        frame = requestAnimationFrame(expand);
      }
    };

    frame = requestAnimationFrame(expand);

    return () => {
      cancelAnimationFrame(frame);
    };
  }, [shockwaveActive, shockwaveOrigin]);

  return (
    <canvas
      ref={canvasRef}
      className="pointer-events-none absolute inset-0 z-10 h-full w-full"
      aria-hidden="true"
    />
  );
};
