import React from 'react';
import { WaterDropletsLayer } from './WaterDropletsLayer';

interface LogoSectionProps {
  introPhase: number;
  parallaxOffset: { x: number; y: number };
}

export const LogoSection: React.FC<LogoSectionProps> = ({
  introPhase,
  parallaxOffset,
}) => {
  // Parallax transform with subtle 3D tilt
  const logoParallax = {
    transform: `translate3d(${parallaxOffset.x * 22}px, ${parallaxOffset.y * 18}px, 0) scale(${
      introPhase >= 3 ? 1 : 0.92
    })`,
    transition: 'transform 0.18s cubic-bezier(0.16, 1, 0.3, 1), opacity 0.8s ease-out',
    opacity: introPhase >= 3 ? 1 : 0,
  };

  return (
    <div
      className="relative z-20 flex w-full max-w-4xl flex-col items-center justify-center px-4 text-center will-change-transform"
      style={logoParallax}
    >
      {/* Container for logo and interactive water drops */}
      <div className="relative mb-3 flex flex-col items-center justify-center select-none">
        {/* Dynamic Specular Sheen Sweep Effect */}
        <div className="pointer-events-none absolute inset-0 overflow-hidden opacity-40">
          <div className="animate-sheen h-full w-1/3 bg-gradient-to-r from-transparent via-white/50 to-transparent blur-sm" />
        </div>

        {/* 3D Liquid Glass & Chrome Lettering */}
        <div className="relative flex flex-col items-center leading-none tracking-tight">
          {/* NET: Glossy Ruby Red */}
          <div className="relative">
            <h1
              className="font-orbitron text-4xl xs:text-5xl font-black tracking-wider sm:text-7xl md:text-8xl lg:text-9xl"
              style={{
                background: 'linear-gradient(180deg, #ff6b8b 0%, #ff0033 40%, #a00020 75%, #4a000e 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                filter: 'drop-shadow(0 0 25px rgba(255, 0, 51, 0.75)) drop-shadow(0 8px 16px rgba(0, 0, 0, 0.95))',
                textShadow: '0 0 30px rgba(255, 0, 51, 0.5)',
              }}
            >
              NET
            </h1>
            {/* Glossy top edge highlight for 3D extrusion illusion */}
            <span
              aria-hidden="true"
              className="font-orbitron pointer-events-none absolute inset-0 text-4xl xs:text-5xl font-black tracking-wider opacity-60 sm:text-7xl md:text-8xl lg:text-9xl"
              style={{
                background: 'linear-gradient(180deg, rgba(255, 255, 255, 0.8) 0%, transparent 35%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              NET
            </span>
          </div>

          {/* MIRROR: Liquid Polished Chrome Silver */}
          <div className="relative -mt-2 sm:-mt-4 md:-mt-6">
            <h2
              className="font-orbitron text-3xl xs:text-4xl font-black tracking-widest sm:text-6xl md:text-7xl lg:text-8xl"
              style={{
                background: 'linear-gradient(180deg, #ffffff 0%, #f1f5f9 25%, #94a3b8 50%, #ffffff 52%, #cbd5e1 75%, #475569 100%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
                filter: 'drop-shadow(0 0 20px rgba(255, 255, 255, 0.4)) drop-shadow(0 10px 20px rgba(0, 0, 0, 0.95))',
              }}
            >
              MIRROR
            </h2>
            {/* Mirror reflection sheen layer */}
            <span
              aria-hidden="true"
              className="font-orbitron pointer-events-none absolute inset-0 text-3xl xs:text-4xl font-black tracking-widest opacity-70 sm:text-6xl md:text-7xl lg:text-8xl"
              style={{
                background: 'linear-gradient(180deg, rgba(255, 255, 255, 0.95) 0%, transparent 40%)',
                WebkitBackgroundClip: 'text',
                WebkitTextFillColor: 'transparent',
              }}
            >
              MIRROR
            </span>
          </div>
        </div>

        {/* Water Droplets Layer sliding down the letters with transparent trails */}
        <WaterDropletsLayer />
      </div>

      {/* Primary Headline: BEYOND WHAT YOU SEE */}
      <div
        className="relative mt-2 overflow-hidden px-4 transition-all duration-700 md:mt-3"
        style={{
          opacity: introPhase >= 4 ? 1 : 0,
          transform: introPhase >= 4 ? 'translateY(0)' : 'translateY(12px)',
        }}
      >
        <p
          className="font-montserrat text-xs font-bold tracking-[0.38em] text-white/90 uppercase sm:text-sm md:text-base"
          style={{
            textShadow: '0 0 12px rgba(255, 255, 255, 0.6), 0 2px 4px rgba(0,0,0,0.9)',
          }}
        >
          BEYOND WHAT YOU SEE
        </p>
        {/* Subtle red neon baseline divider */}
        <div className="mx-auto mt-2 h-[1px] w-24 bg-gradient-to-r from-transparent via-[#ff0033] to-transparent opacity-80 sm:w-36" />
      </div>
    </div>
  );
};
