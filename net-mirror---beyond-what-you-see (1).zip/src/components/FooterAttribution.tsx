import React from 'react';

interface FooterAttributionProps {
  introPhase: number;
}

export const FooterAttribution: React.FC<FooterAttributionProps> = ({ introPhase }) => {
  return (
    <footer
      className="absolute bottom-3 left-0 right-0 z-20 flex items-center justify-center px-4 transition-opacity duration-1000 select-none sm:bottom-4"
      style={{
        opacity: introPhase >= 4 ? 0.8 : 0,
      }}
    >
      <div className="flex items-center gap-2 text-center">
        <span className="font-montserrat text-[11px] font-medium tracking-[0.25em] text-neutral-400 uppercase sm:text-xs">
          developed by <strong className="font-semibold text-neutral-200 hover:text-[#ff0033] transition-colors">Shan Awan</strong>
        </span>
      </div>
    </footer>
  );
};
