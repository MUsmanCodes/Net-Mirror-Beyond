import React, { useState } from 'react';
import { Volume2, VolumeX } from 'lucide-react';
import { soundSynth } from '../utils/audio';

export const AudioController: React.FC = () => {
  const [isMuted, setIsMuted] = useState(soundSynth.getIsMuted());

  const handleToggle = () => {
    const nextState = soundSynth.toggleMute();
    setIsMuted(nextState);
    if (!nextState) {
      soundSynth.playWaterDrip();
    }
  };

  return (
    <div className="absolute top-4 right-4 z-30 sm:top-6 sm:right-6">
      <button
        type="button"
        onClick={handleToggle}
        aria-label={isMuted ? 'Unmute cinematic sound effects' : 'Mute sound effects'}
        title={isMuted ? 'Sound: Muted (Click to enable atmospheric sounds)' : 'Sound: Enabled'}
        className="flex h-9 w-9 items-center justify-center rounded-full border border-neutral-800 bg-black/60 text-neutral-400 backdrop-blur-sm transition-all duration-200 hover:border-red-600/60 hover:text-white hover:shadow-[0_0_15px_rgba(255,0,51,0.5)] focus-visible:ring-2 focus-visible:ring-[#ff0033] outline-none"
      >
        {isMuted ? (
          <VolumeX className="h-4 w-4" aria-hidden="true" />
        ) : (
          <Volume2 className="h-4 w-4 text-[#ff0033]" aria-hidden="true" />
        )}
      </button>
    </div>
  );
};
