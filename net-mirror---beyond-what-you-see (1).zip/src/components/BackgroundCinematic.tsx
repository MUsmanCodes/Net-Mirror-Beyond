import React, { useState, useEffect } from 'react';

interface BackgroundCinematicProps {
  parallaxOffset: { x: number; y: number };
  introPhase: number; // 0 to 4
}

export const BackgroundCinematic: React.FC<BackgroundCinematicProps> = ({
  parallaxOffset,
  introPhase,
}) => {
  const [imageLoaded, setImageLoaded] = useState(false);
  const imageSrc = '/assets/aistudio/image_30c84057.png';

  useEffect(() => {
    const img = new Image();
    img.src = imageSrc;
    img.onload = () => setImageLoaded(true);
  }, [imageSrc]);

  // Interpolated smooth parallax coordinates
  const transformStyle = {
    transform: `scale(1.05) translate3d(${parallaxOffset.x * 14}px, ${parallaxOffset.y * 10}px, 0)`,
    transition: 'transform 0.15s cubic-bezier(0.2, 0.8, 0.2, 1)',
  };

  return (
    <div className="pointer-events-none absolute inset-0 z-0 overflow-hidden bg-black select-none">
      {/* 1. Deep ambient red radial aura */}
      <div
        className="absolute inset-0 bg-[radial-gradient(ellipse_at_50%_35%,rgba(139,0,0,0.5)_0%,rgba(20,0,5,0.85)_50%,#000000_85%)] transition-opacity duration-1000"
        style={{ opacity: introPhase >= 1 ? 1 : 0.2 }}
      />

      {/* 2. Central glowing red portal ring backdrop */}
      <div
        className="absolute top-[28%] left-1/2 h-[340px] w-[340px] -translate-x-1/2 -translate-y-1/2 rounded-full md:h-[520px] md:w-[520px]"
        style={{
          background: 'radial-gradient(circle, rgba(255,0,51,0.25) 0%, rgba(139,0,0,0.1) 45%, transparent 70%)',
          boxShadow: '0 0 100px 20px rgba(255,0,51,0.3)',
          opacity: introPhase >= 1 ? 1 : 0,
          transition: 'opacity 1.5s ease-out',
        }}
      />

      {/* 3. Primary Cinematic Artwork Layer with Parallax */}
      <div
        className="absolute inset-0 flex items-center justify-center will-change-transform"
        style={transformStyle}
      >
        <img
          src={imageSrc}
          alt="NET MIRROR Cinematic Superhero Beast Background"
          className={`h-full w-full object-cover object-center transition-all duration-1000 ${
            introPhase >= 2 ? 'opacity-100 scale-100' : 'opacity-0 scale-105'
          } ${imageLoaded ? 'filter-none' : 'blur-sm'}`}
          referrerPolicy="no-referrer"
          fetchPriority="high"
        />
      </div>

      {/* 4. Atmospheric Vignette & Contrast Control (Ensures readability across all displays) */}
      <div className="absolute inset-0 bg-gradient-to-t from-black via-black/35 to-black/60 pointer-events-none" />
      <div className="absolute inset-0 bg-gradient-to-r from-black/60 via-transparent to-black/60 pointer-events-none" />

      {/* 5. Dynamic Red Horizon Glow Pulse */}
      <div
        className="pointer-events-none absolute bottom-0 left-0 right-0 h-48 bg-gradient-to-t from-black via-[#ff0033]/10 to-transparent transition-opacity duration-1000"
        style={{ opacity: introPhase >= 3 ? 0.75 : 0 }}
      />
    </div>
  );
};
