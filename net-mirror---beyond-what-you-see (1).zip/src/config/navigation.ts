/**
 * NET MIRROR - Destination URL Configuration
 * 
 * ====================================================================
 * INSTRUCTIONS FOR ADDING YOUR DESTINATION URL:
 * ====================================================================
 * 1. Replace the empty string below with your destination website URL.
 *    For example:
 *    export const DESTINATION_URL = "https://your-target-website.com";
 * 
 * 2. The URL must include the protocol (https:// or http://).
 * 3. When visitors click the "ENTER NET MIRROR" button, this website
 *    will open safely in a new browser tab while keeping NET MIRROR open.
 * 4. Leaving this as empty string ("") triggers a helpful guidance modal
 *    in the UI explaining how to set the destination.
 * ====================================================================
 */

export const DESTINATION_URL = "https://net77.cc/home?utm_source=home_page";
